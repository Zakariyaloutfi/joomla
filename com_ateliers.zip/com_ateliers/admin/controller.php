<?php
defined('_JEXEC') or die;

class AteliersController extends JControllerLegacy
{
    protected $default_view = 'ateliers';
}