<?php
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

class AteliersController extends BaseController
{
    protected $default_view = 'ateliers'; // Vue par défaut
}
